package main

type Tdp struct {
	A_pemohon         string `json:"a_pemohon"`
	Alamat_perusahaan string
	Catatan           string
	I_telp_perusahaan string
	Id_permohonan     int `json:"id_permohonan"`
	N_pemohon         string
	N_perusahaan      string
	Nama_pimpinan     string
	Nip_ttd           string
	No_pendaftaran    string
	No_reg_perusahaan string
	No_surat          string
	No_surat_edit     string
	Npwp              string
	Ref_pendataran    string
	Telp_pemohon      string
	Tgl               string
	Tgl_surat         string
	Tgl_surat_edit    string
}
